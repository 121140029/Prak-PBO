from tkinter import *

root = Tk()
root.title("To Do List")
root.geometry("400x610+400+100")
root.resizable(False, False)

task_list = []

def addTask():
    task = task_entry.get()
    task_entry.delete(0, END)
    
    if task:
        with open("Tasklist.txt", 'a') as taskfile:
            taskfile.write(f"\n{task}")
        task_list.append(task)
        listbox.insert(END, task)    

def deleteTask():
    global task_list
    task = str(listbox.get(ANCHOR))
    if task in task_list:
        task_list.remove(task)
        with open("Tasklist.txt", 'w') as taskfile:
            for task in task_list:
                taskfile.write(task + "\n")
                
        listbox.delete(ANCHOR)
                
def markAsDone():
    task_index = listbox.curselection()
    if task_index:
        task = listbox.get(task_index)
        listbox.delete(task_index)
        completed_listbox.insert(END, task)
        
        with open("Tasklist.txt", 'w') as taskfile:
            for item in listbox.get(0, END):
                taskfile.write(item + "\n")
                
        with open("Tasklistdone.txt", 'a') as taskfile_done:
            taskfile_done.write(task + "\n")    
    
def openTaskFile():    
    try:
        global task_list
        with open("Tasklist.txt", "r") as taskfile:
            tasks = taskfile.readlines()
        
        for task in tasks:
            if task != '\n':
                task_list.append(task)
                listbox.insert(END, task)
                
    except:
        file = open('Tasklist.txt', 'w')
        file.close()

#Icon
Image_icon = PhotoImage(file = "Image/Task.png")
root.iconphoto(False, Image_icon)

#Top bar
TopImage = PhotoImage(file = "Image/Topbar.png")
Label(root, image = TopImage).pack()

dockImage = PhotoImage(file = "Image/Dock.png")
Label(root, image = dockImage, bg = "#3f48cc").place(x = 30, y = 27)

noteImage = PhotoImage(file = "Image/Tasktitle.png")
Label(root, image = noteImage, bg = "#3f48cc").place(x = 315, y = 14)

heading = Label(root, text = "ALL TASK", font = "calibri 20 bold", fg = "white", bg = "#3f48cc")
heading.place(x = 135, y = 19)

#Main
frame = Frame(root, width = 400, height = 50, bg = "white")
frame.place(x = 0, y = 90)

task = StringVar()
task_entry = Entry(frame, width = 22, font = "calibri 18", bd = 0)
task_entry.place(x = 10, y = 7)
task_entry.focus()

button = Button (frame, text = "ADD", font = "arial 18 bold", width = 6, bg = "#5a95ff", fg = "#fff", bd = 2, command = addTask)
button.place(x = 300, y = 0)

#Listbox
frame1 = Frame(root, bd = 3, width = 700, height = 280, bg = "#3f48cc")
frame1.place(x = 0, y = 150)

listbox = Listbox(frame1, font = ('calibri', 12), width = 46, height = 10, bg = "#3f48cc", fg = "white", cursor = "hand2", selectbackground = "#5a95ff")
listbox.pack(side = LEFT, fill = BOTH, padx = 2)
scrollbar = Scrollbar(frame1)
scrollbar.pack(side = RIGHT, fill = BOTH)

listbox.config(yscrollcommand = scrollbar.set)
scrollbar.config(command = listbox.yview)

#Mark As Done
frame3 = Frame(root, width = 400, height = 35, bg = "#0aa436")
frame3.place(x = 0, y = 432)

complete_title = Label(frame3, text = "TASK COMPLETE", font = "calibri 18 bold", fg = "white", bg = "#0aa436")
complete_title.place(x = 118, y = 0)

completed_task_list = []

completed_frame = Frame(root, bd =3, width = 400, height = 40, bg = "#7ef7a0")
completed_frame.place(x = 0, y = 480)

completed_listbox = Listbox(completed_frame, font = ('calibri', 12), width = 46, height = 5, bg = "#7ef7a0", fg = "black", cursor = "hand2")
completed_listbox.pack(side = LEFT, fill = BOTH, padx = 2)
completed_scrollbar = Scrollbar(completed_frame)
completed_scrollbar.pack(side = RIGHT, fill = BOTH)

completed_listbox.config(yscrollcommand = completed_scrollbar.set)
completed_scrollbar.config(command = completed_listbox.yview)

mark_button = Button (root, text = "MARK", font = "arial 16 bold", width = 8, bg = "#076e24", fg = "#fff", bd = 2, command = markAsDone)
mark_button.place(x = 190, y = 370)

openTaskFile()

#Delete
Delete_icon = PhotoImage(file = "Image/Delete.png")
Button(root, image = Delete_icon, bd = 0, command = deleteTask).place(x = 110, y = 370)

root.mainloop()